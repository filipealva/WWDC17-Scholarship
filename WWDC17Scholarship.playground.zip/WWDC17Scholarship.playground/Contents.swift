//: Filipe Alvarenga - Student, iOS developer, design enthusiastic & entrepreneur

import UIKit
import WWDC17Scholarship_Sources
import PlaygroundSupport

PlaygroundPage.current.liveView = DotsViewController().view
PlaygroundPage.current.needsIndefiniteExecution = true

